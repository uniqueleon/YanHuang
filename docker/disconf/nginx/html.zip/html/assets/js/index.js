(function ($) {

    $("#indexMain").attr("href", "/");

    getSession2Redirect();

})(jQuery);